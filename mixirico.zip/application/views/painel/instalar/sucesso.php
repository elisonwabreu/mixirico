<?php if ( ! defined("BASEPATH")) exit("No direct script access allowed");

		?>
		<div class="seven columns centered" style="margin-top: 50px;">
			<div class="panel">
				<h6>Instalação concluída!</h6>
				<p>O sistema foi instalado com sucesso, você já pode começar a utilizá-lo agora.</p>
				<a href="<?php echo base_url('usuarios/login') ?>" class="button radius success">Fazer login</a>
			</div>
		</div>