<?php if ( ! defined("BASEPATH")) exit("No direct script access allowed");

//echo get_setting('sobreEmpresa');
echo get_setting('txt_home');